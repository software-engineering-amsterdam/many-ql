/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * This file is part of AntTask.                             *
 * See the file "LICENSE" for copyright information and the  *
 * terms and conditions for copying, distribution and        *
 * modification of AntTask.                                  *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package org.apache.tools.ant.taskdefs;

import org.apache.tools.ant.*;
import java.io.*;

public class MatchingTask extends Task
{
  protected DirectoryScanner getDirectoryScanner(File baseDir)
  {
    return null;
  }
}

