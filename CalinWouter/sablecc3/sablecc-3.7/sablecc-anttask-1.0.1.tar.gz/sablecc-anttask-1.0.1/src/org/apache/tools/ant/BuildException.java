/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * This file is part of AntTask.                             *
 * See the file "LICENSE" for copyright information and the  *
 * terms and conditions for copying, distribution and        *
 * modification of AntTask.                                  *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package org.apache.tools.ant;

public class BuildException extends RuntimeException
{
  public BuildException(java.lang.String msg)
  {
  }
}
