/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * This file is part of AntTask.                             *
 * See the file "LICENSE" for copyright information and the  *
 * terms and conditions for copying, distribution and        *
 * modification of AntTask.                                  *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package org.sablecc.sablecc;

import java.io.*;

public class SableCC
{
  public static void processGrammar(String grammar, String destDir) throws Exception, Throwable 
  {
  }
}
